export class AuthPayloadDto {
  username: string;
  password: string;
}