export enum Role {
  User = 'user',
  Doctor = 'doctor',
  Staff  = 'staff',
  Admin = 'admin',
  SuperAdmin = 'superadmin',
}